#ifndef HEAP_H_
#define HEAP_H_

#include "CoOS.h"

/*
#define malloc	CoKmalloc
#define free	CoKfree
*/

static inline void* malloc(U32 size)
{
	return CoKmalloc(size);
}

static inline void free(void* memBuf)
{
	CoKfree(memBuf);
}

#endif /* HEAP_H_ */
